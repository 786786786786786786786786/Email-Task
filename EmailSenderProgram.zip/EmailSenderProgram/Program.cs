﻿using System;
using System.Collections.Generic;
using System.Net.Mail;

namespace EmailSenderProgram
{
    public enum EmailType
    {
        WelcomeMail,
        ComebackMail
    }

    internal class Program
    {
        private static void Main(string[] args)
        {
            SendEmail(EmailType.WelcomeMail, "Welcome mail");

#if DEBUG
            // Debug mode: always send comeback mail
            SendEmail(EmailType.ComebackMail, "EOComebackToUs");
#else
            // Every Monday, send comeback mail
            if (DateTime.Now.DayOfWeek == DayOfWeek.Monday)
            {
                SendEmail(EmailType.ComebackMail, "EOComebackToUs");
            }
#endif

            Console.ReadKey();
        }

        private static void SendEmail(EmailType emailType, string voucher)
        {
            try
            {
                List<Customer> customers = DataLayer.ListCustomers();

                foreach (Customer customer in customers)
                {
                    MailMessage message = new MailMessage();
                    message.To.Add(customer.Email);

                    switch (emailType)
                    {
                        case EmailType.WelcomeMail:
                            if (customer.CreatedDateTime > DateTime.Now.AddDays(-1))
                            {
                                PrepareAndSendEmail(message, "Welcome as a new customer at EO!",
                                    "Hi " + customer.Email +
                                    "<br>We would like to welcome you as a customer on our site!<br><br>Best Regards,<br>EO Team");
                            }
                            break;

                        case EmailType.ComebackMail:
                            if (!CustomerHasPlacedOrder(customer))
                            {
                                PrepareAndSendEmail(message, "We miss you as a customer",
                                    "Hi " + customer.Email +
                                    "<br>We miss you as a customer. Our shop is filled with nice products. Here is a voucher that gives you 50 kr to shop for." +
                                    "<br>Voucher: " + voucher +
                                    "<br><br>Best Regards,<br>EO Team");
                            }
                            break;
                    }
                }

                Console.WriteLine($"Emails of type {emailType} sent successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to send emails of type {emailType}. Error: {ex.Message}");
            }
        }

        private static bool CustomerHasPlacedOrder(Customer customer)
        {
            List<Order> orders = DataLayer.ListOrders();

            foreach (Order order in orders)
            {
                if (customer.Email == order.CustomerEmail)
                {
                    return true;
                }
            }

            return false;
        }

        private static void PrepareAndSendEmail(MailMessage message, string subject, string body)
        {
            message.Subject = subject;
            message.From = new MailAddress("info@EO.com");
            message.Body = body;

#if !DEBUG
            SmtpClient smtp = new SmtpClient("yoursmtphost");
            smtp.Send(message);
            Console.WriteLine($"Sent email to: {message.To}");
#else
            Console.WriteLine($"Email prepared for: {message.To}");
#endif
        }
    }

 
}
